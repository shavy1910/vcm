/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ReminderForm extends JFrame implements ActionListener {

    // Labels
    JLabel lblReminderID, lblCitizenID, lblCenterID, lblDosageID, lblReminderDate, lblReminderTime;
    
    // Text fields
    JTextField txtReminderID, txtCitizenID, txtCenterID, txtDosageID, txtReminderDate, txtReminderTime;
    
    // Buttons
    JButton btnSubmit, btnReset;
    
    public ReminderForm() {
        // Frame settings
        setTitle("Reminder Form");
        setSize(400, 300);
        setLayout(new GridLayout(7, 2));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Initialize Labels
        lblReminderID = new JLabel("Reminder ID:");
        lblCitizenID = new JLabel("Citizen ID:");
        lblCenterID = new JLabel("Center ID:");
        lblDosageID = new JLabel("Dosage ID:");
        lblReminderDate = new JLabel("Reminder Date:");
        lblReminderTime = new JLabel("Reminder Time:");
        
        // Initialize Text Fields
        txtReminderID = new JTextField(20);
        txtCitizenID = new JTextField(20);
        txtCenterID = new JTextField(20);
        txtDosageID = new JTextField(20);
        txtReminderDate = new JTextField(20);
        txtReminderTime = new JTextField(20);
        
        // Initialize Buttons
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        
        btnReset = new JButton("Reset");
        btnReset.addActionListener(this);
        
        // Add components to the frame
        add(lblReminderID); add(txtReminderID);
        add(lblCitizenID); add(txtCitizenID);
        add(lblCenterID); add(txtCenterID);
        add(lblDosageID); add(txtDosageID);
        add(lblReminderDate); add(txtReminderDate);
        add(lblReminderTime); add(txtReminderTime);
        add(btnSubmit); add(btnReset);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnSubmit) {
            // Retrieve data from the form fields
            String reminderID = txtReminderID.getText();
            String citizenID = txtCitizenID.getText();
            String centerID = txtCenterID.getText();
            String dosageID = txtDosageID.getText();
            String reminderDate = txtReminderDate.getText();
            String reminderTime = txtReminderTime.getText();
            
            // Database operations
            Connection conn = null;
            PreparedStatement pstmt = null;

            try {
                // Get database connection
                conn = DatabaseConnection.getConnection();

                // SQL insert statement
                String sql = "INSERT INTO tbReminder (ReminderID, CitizenID, CenterID, DosageID, ReminderDate, ReminderTime) " +
                             "VALUES (?, ?, ?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, reminderID);
                pstmt.setString(2, citizenID);
                pstmt.setString(3, centerID);
                pstmt.setString(4, dosageID);
                pstmt.setString(5, reminderDate);
                pstmt.setString(6, reminderTime);

                // Execute the statement
                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(this, "Reminder set successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                // Clean up resources
                DatabaseConnection.closeConnection(conn);
                try {
                    if (pstmt != null) pstmt.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } else if(e.getSource() == btnReset) {
            // Clear all the text fields
            txtReminderID.setText("");
            txtCitizenID.setText("");
            txtCenterID.setText("");
            txtDosageID.setText("");
            txtReminderDate.setText("");
            txtReminderTime.setText("");
        }
    }
    
    public static void main(String[] args) {
        ReminderForm form = new ReminderForm();
        form.setVisible(true);
    }
}