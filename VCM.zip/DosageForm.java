/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DosageForm extends JFrame implements ActionListener {

    // Labels
    JLabel lblDosageID, lblCenterID, lblCitizenID, lblMedicineID, lblDOVOne, lblTimeOne, lblNextDate, lblDOVTwo, lblTimeTwo;
    
    // Text fields
    JTextField txtDosageID, txtCenterID, txtCitizenID, txtMedicineID, txtDOVOne, txtTimeOne, txtNextDate, txtDOVTwo, txtTimeTwo;
    
    // Buttons
    JButton btnSubmit, btnReset;
    
    public DosageForm() {
        // Frame settings
        setTitle("Dosage Form");
        setSize(400, 400);
        setLayout(new GridLayout(10, 2));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Initialize Labels
        lblDosageID = new JLabel("Dosage ID:");
        lblCenterID = new JLabel("Center ID:");
        lblCitizenID = new JLabel("Citizen ID:");
        lblMedicineID = new JLabel("Medicine ID:");
        lblDOVOne = new JLabel("Date of First Vaccination:");
        lblTimeOne = new JLabel("Time of First Vaccination:");
        lblNextDate = new JLabel("Next Vaccination Date:");
        lblDOVTwo = new JLabel("Date of Second Vaccination:");
        lblTimeTwo = new JLabel("Time of Second Vaccination:");
        
        // Initialize Text Fields
        txtDosageID = new JTextField(20);
        txtCenterID = new JTextField(20);
        txtCitizenID = new JTextField(20);
        txtMedicineID = new JTextField(20);
        txtDOVOne = new JTextField(20);
        txtTimeOne = new JTextField(20);
        txtNextDate = new JTextField(20);
        txtDOVTwo = new JTextField(20);
        txtTimeTwo = new JTextField(20);
        
        // Initialize Buttons
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        
        btnReset = new JButton("Reset");
        btnReset.addActionListener(this);
        
        // Add components to the frame
        add(lblDosageID); add(txtDosageID);
        add(lblCenterID); add(txtCenterID);
        add(lblCitizenID); add(txtCitizenID);
        add(lblMedicineID); add(txtMedicineID);
        add(lblDOVOne); add(txtDOVOne);
        add(lblTimeOne); add(txtTimeOne);
        add(lblNextDate); add(txtNextDate);
        add(lblDOVTwo); add(txtDOVTwo);
        add(lblTimeTwo); add(txtTimeTwo);
        add(btnSubmit); add(btnReset);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnSubmit) {
            // Retrieve data from the form fields
            String dosageID = txtDosageID.getText();
            String centerID = txtCenterID.getText();
            String citizenID = txtCitizenID.getText();
            String medicineID = txtMedicineID.getText();
            String dovOne = txtDOVOne.getText();
            String timeOne = txtTimeOne.getText();
            String nextDate = txtNextDate.getText();
            String dovTwo = txtDOVTwo.getText();
            String timeTwo = txtTimeTwo.getText();
            
            // Database operations
            Connection conn = null;
            PreparedStatement pstmt = null;

            try {
                // Get database connection
                conn = DatabaseConnection.getConnection();

                // SQL insert statement
                String sql = "INSERT INTO tbDosage (DosageID, CenterID, CitizenID, MedicineID, DOVOne, TimeOne, NextDate, DOVTwo, TimeTwo) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, dosageID);
                pstmt.setString(2, centerID);
                pstmt.setString(3, citizenID);
                pstmt.setString(4, medicineID);
                pstmt.setString(5, dovOne);
                pstmt.setString(6, timeOne);
                pstmt.setString(7, nextDate);
                pstmt.setString(8, dovTwo);
                pstmt.setString(9, timeTwo);

                // Execute the statement
                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(this, "Dosage data saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                // Clean up resources
                DatabaseConnection.closeConnection(conn);
                try {
                    if (pstmt != null) pstmt.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } else if(e.getSource() == btnReset) {
            // Clear all the text fields
            txtDosageID.setText("");
            txtCenterID.setText("");
            txtCitizenID.setText("");
            txtMedicineID.setText("");
            txtDOVOne.setText("");
            txtTimeOne.setText("");
            txtNextDate.setText("");
            txtDOVTwo.setText("");
            txtTimeTwo.setText("");
        }
    }
    
    public static void main(String[] args) {
        DosageForm form = new DosageForm();
        form.setVisible(true);
    }
}