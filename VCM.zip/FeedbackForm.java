/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class FeedbackForm extends JFrame implements ActionListener {

    // Labels
    JLabel lblFeedbackID, lblCitizenID, lblDateOfFeedback, lblRemarks, lblActionDetails, lblStatus;
    
    // Text fields
    JTextField txtFeedbackID, txtCitizenID, txtDateOfFeedback, txtRemarks, txtActionDetails, txtStatus;
    
    // Buttons
    JButton btnSubmit, btnReset;
    
    public FeedbackForm() {
        // Frame settings
        setTitle("Feedback Form");
        setSize(400, 300);
        setLayout(new GridLayout(7, 2));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Initialize Labels
        lblFeedbackID = new JLabel("Feedback ID:");
        lblCitizenID = new JLabel("Citizen ID:");
        lblDateOfFeedback = new JLabel("Date of Feedback:");
        lblRemarks = new JLabel("Remarks:");
        lblActionDetails = new JLabel("Action Details:");
        lblStatus = new JLabel("Status:");
        
        // Initialize Text Fields
        txtFeedbackID = new JTextField(20);
        txtCitizenID = new JTextField(20);
        txtDateOfFeedback = new JTextField(20);
        txtRemarks = new JTextField(20);
        txtActionDetails = new JTextField(20);
        txtStatus = new JTextField(20);
        
        // Initialize Buttons
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        
        btnReset = new JButton("Reset");
        btnReset.addActionListener(this);
        
        // Add components to the frame
        add(lblFeedbackID); add(txtFeedbackID);
        add(lblCitizenID); add(txtCitizenID);
        add(lblDateOfFeedback); add(txtDateOfFeedback);
        add(lblRemarks); add(txtRemarks);
        add(lblActionDetails); add(txtActionDetails);
        add(lblStatus); add(txtStatus);
        add(btnSubmit); add(btnReset);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnSubmit) {
            // Retrieve data from the form fields
            String feedbackID = txtFeedbackID.getText();
            String citizenID = txtCitizenID.getText();
            String dateOfFeedback = txtDateOfFeedback.getText();
            String remarks = txtRemarks.getText();
            String actionDetails = txtActionDetails.getText();
            String status = txtStatus.getText();
            
            // Display the data in the console (for testing purposes)
            System.out.println("Feedback Details:");
            System.out.println("Feedback ID: " + feedbackID);
            System.out.println("Citizen ID: " + citizenID);
            System.out.println("Date of Feedback: " + dateOfFeedback);
            System.out.println("Remarks: " + remarks);
            System.out.println("Action Details: " + actionDetails);
            System.out.println("Status: " + status);
            
            // Display a confirmation message
            JOptionPane.showMessageDialog(this, "Feedback submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else if(e.getSource() == btnReset) {
            // Clear all the text fields
            txtFeedbackID.setText("");
            txtCitizenID.setText("");
            txtDateOfFeedback.setText("");
            txtRemarks.setText("");
            txtActionDetails.setText("");
            txtStatus.setText("");
        }
    }
    
    public static void main(String[] args) {
        FeedbackForm form = new FeedbackForm();
        form.setVisible(true);
    }
}