/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends JFrame implements ActionListener {

    // Buttons for navigation
    JButton btnVaccinationCenter, btnMedicine, btnCitizen, btnDosage, btnCertificate, btnFeedback, btnReminder;
    
    public MainMenu() {
        // Frame settings
        setTitle("Main Menu");
        setSize(400, 300);
        setLayout(new GridLayout(7, 1, 10, 10));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Initialize Buttons
        btnVaccinationCenter = new JButton("Vaccination Center Form");
        btnMedicine = new JButton("Medicine Form");
        btnCitizen = new JButton("Citizen Form");
        btnDosage = new JButton("Dosage Form");
        btnCertificate = new JButton("Certificate Form");
        btnFeedback = new JButton("Feedback Form");
        btnReminder = new JButton("Reminder Form");
        
        // Add ActionListeners
        btnVaccinationCenter.addActionListener(this);
        btnMedicine.addActionListener(this);
        btnCitizen.addActionListener(this);
        btnDosage.addActionListener(this);
        btnCertificate.addActionListener(this);
        btnFeedback.addActionListener(this);
        btnReminder.addActionListener(this);
        
        // Add components to the frame
        add(btnVaccinationCenter);
        add(btnMedicine);
        add(btnCitizen);
        add(btnDosage);
        add(btnCertificate);
        add(btnFeedback);
        add(btnReminder);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        // Open the corresponding form based on the button clicked
        if(e.getSource() == btnVaccinationCenter) {
            new VaccinationCenterForm().setVisible(true);
        } else if(e.getSource() == btnMedicine) {
            new MedicineForm().setVisible(true);
        } else if(e.getSource() == btnCitizen) {
            new CitizenForm().setVisible(true);
        } else if(e.getSource() == btnDosage) {
            new DosageForm().setVisible(true);
        } else if(e.getSource() == btnCertificate) {
            new CertificateForm().setVisible(true);
        } else if(e.getSource() == btnFeedback) {
            new FeedbackForm().setVisible(true);
        } else if(e.getSource() == btnReminder) {
            new ReminderForm().setVisible(true);
        }
    }
    
    public static void main(String[] args) {
        MainMenu menu = new MainMenu();
        menu.setVisible(true);
    }
}