/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CitizenForm extends JFrame implements ActionListener {

    // Labels
    JLabel lblCitizenID, lblName, lblFname, lblAddress, lblPhone, lblEmail, lblAadhar, lblDOR;
    
    // Text fields
    JTextField txtCitizenID, txtName, txtFname, txtAddress, txtPhone, txtEmail, txtAadhar, txtDOR;
    
    // Buttons
    JButton btnSubmit, btnReset;
    
    public CitizenForm() {
        // Frame settings
        setTitle("Citizen Form");
        setSize(350, 400);
        setLayout(new GridLayout(9, 2));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Initialize Labels
        lblCitizenID = new JLabel("Citizen ID:");
        lblName = new JLabel("Name:");
        lblFname = new JLabel("Father's Name:");
        lblAddress = new JLabel("Address:");
        lblPhone = new JLabel("Phone:");
        lblEmail = new JLabel("Email:");
        lblAadhar = new JLabel("Aadhar Number:");
        lblDOR = new JLabel("Date of Registration (DOR):");
        
        // Initialize Text Fields
        txtCitizenID = new JTextField(20);
        txtName = new JTextField(20);
        txtFname = new JTextField(20);
        txtAddress = new JTextField(20);
        txtPhone = new JTextField(20);
        txtEmail = new JTextField(20);
        txtAadhar = new JTextField(20);
        txtDOR = new JTextField(20);
        
        // Initialize Buttons
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        
        btnReset = new JButton("Reset");
        btnReset.addActionListener(this);
        
        // Add components to the frame
        add(lblCitizenID); add(txtCitizenID);
        add(lblName); add(txtName);
        add(lblFname); add(txtFname);
        add(lblAddress); add(txtAddress);
        add(lblPhone); add(txtPhone);
        add(lblEmail); add(txtEmail);
        add(lblAadhar); add(txtAadhar);
        add(lblDOR); add(txtDOR);
        add(btnSubmit); add(btnReset);
    }
    
    // Method to establish a connection to the database
    public Connection getConnection() {
        Connection conn = null;
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish a connection
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database_name", "your_username", "your_password");
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnSubmit) {
            // Retrieve data from the form fields
            String citizenID = txtCitizenID.getText();
            String name = txtName.getText();
            String fname = txtFname.getText();
            String address = txtAddress.getText();
            String phone = txtPhone.getText();
            String email = txtEmail.getText();
            String aadhar = txtAadhar.getText();
            String dor = txtDOR.getText();
            
            // Insert data into the database
            Connection conn = getConnection();
            if(conn != null) {
                try {
                    String query = "INSERT INTO citizen_table (citizen_id, name, father_name, address, phone, email, aadhar, dor) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement pstmt = conn.prepareStatement(query);
                    pstmt.setString(1, citizenID);
                    pstmt.setString(2, name);
                    pstmt.setString(3, fname);
                    pstmt.setString(4, address);
                    pstmt.setString(5, phone);
                    pstmt.setString(6, email);
                    pstmt.setString(7, aadhar);
                    pstmt.setString(8, dor);
                    
                    int rowsInserted = pstmt.executeUpdate();
                    if(rowsInserted > 0) {
                        // Display a confirmation message
                        JOptionPane.showMessageDialog(this, "Data saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                } finally {
                    try {
                        conn.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        } else if(e.getSource() == btnReset) {
            // Clear all the text fields
            txtCitizenID.setText("");
            txtName.setText("");
            txtFname.setText("");
            txtAddress.setText("");
            txtPhone.setText("");
            txtEmail.setText("");
            txtAadhar.setText("");
            txtDOR.setText("");
        }
    }
    
    public static void main(String[] args) {
        CitizenForm form = new CitizenForm();
        form.setVisible(true);
    }
}