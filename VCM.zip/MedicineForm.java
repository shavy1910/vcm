/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MedicineForm extends JFrame implements ActionListener {

    // Labels
    JLabel lblMedicineID, lblCompanyName, lblMedicineName, lblDOI, lblDOE, lblQuantity;
    
    // Text fields
    JTextField txtMedicineID, txtCompanyName, txtMedicineName, txtDOI, txtDOE, txtQuantity;
    
    // Buttons
    JButton btnSubmit, btnReset;
    
    public MedicineForm() {
        // Frame settings
        setTitle("Medicine Form");
        setSize(350, 300);
        setLayout(new GridLayout(7, 2));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Initialize Labels
        lblMedicineID = new JLabel("Medicine ID:");
        lblCompanyName = new JLabel("Company Name:");
        lblMedicineName = new JLabel("Medicine Name:");
        lblDOI = new JLabel("Date of Issue (DOI):");
        lblDOE = new JLabel("Date of Expiry (DOE):");
        lblQuantity = new JLabel("Quantity:");
        
        // Initialize Text Fields
        txtMedicineID = new JTextField(20);
        txtCompanyName = new JTextField(20);
        txtMedicineName = new JTextField(20);
        txtDOI = new JTextField(20);
        txtDOE = new JTextField(20);
        txtQuantity = new JTextField(20);
        
        // Initialize Buttons
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        
        btnReset = new JButton("Reset");
        btnReset.addActionListener(this);
        
        // Add components to the frame
        add(lblMedicineID); add(txtMedicineID);
        add(lblCompanyName); add(txtCompanyName);
        add(lblMedicineName); add(txtMedicineName);
        add(lblDOI); add(txtDOI);
        add(lblDOE); add(txtDOE);
        add(lblQuantity); add(txtQuantity);
        add(btnSubmit); add(btnReset);
    }
    
    // Method to establish a connection to the database
    public Connection getConnection() {
        Connection conn = null;
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish a connection
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database_name", "your_username", "your_password");
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnSubmit) {
            // Retrieve data from the form fields
            String medicineID = txtMedicineID.getText();
            String companyName = txtCompanyName.getText();
            String medicineName = txtMedicineName.getText();
            String doi = txtDOI.getText();
            String doe = txtDOE.getText();
            String quantity = txtQuantity.getText();
            
            // Insert data into the database
            Connection conn = getConnection();
            if(conn != null) {
                try {
                    String query = "INSERT INTO medicine_table (medicine_id, company_name, medicine_name, doi, doe, quantity) VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement pstmt = conn.prepareStatement(query);
                    pstmt.setString(1, medicineID);
                    pstmt.setString(2, companyName);
                    pstmt.setString(3, medicineName);
                    pstmt.setString(4, doi);
                    pstmt.setString(5, doe);
                    pstmt.setString(6, quantity);
                    
                    int rowsInserted = pstmt.executeUpdate();
                    if(rowsInserted > 0) {
                        // Display a confirmation message
                        JOptionPane.showMessageDialog(this, "Data saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                } finally {
                    try {
                        conn.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        } else if(e.getSource() == btnReset) {
            // Clear all the text fields
            txtMedicineID.setText("");
            txtCompanyName.setText("");
            txtMedicineName.setText("");
            txtDOI.setText("");
            txtDOE.setText("");
            txtQuantity.setText("");
        }
    }
    
    public static void main(String[] args) {
        MedicineForm form = new MedicineForm();
        form.setVisible(true);
    }
}