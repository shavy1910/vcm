/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class VaccinationCenterForm extends JFrame implements ActionListener {

    // Labels
    JLabel lblCenterID, lblCenterName, lblAddress, lblPhone, lblEmail, lblInchargeName, lblTimings;
    
    // Text fields
    JTextField txtCenterID, txtCenterName, txtAddress, txtPhone, txtEmail, txtInchargeName, txtTimings;
    
    // Buttons
    JButton btnSubmit, btnReset;
    
    public VaccinationCenterForm() {
        // Frame settings
        setTitle("Vaccination Center Form");
        setSize(400, 400);
        setLayout(new GridLayout(8, 2));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Initialize Labels
        lblCenterID = new JLabel("Center ID:");
        lblCenterName = new JLabel("Center Name:");
        lblAddress = new JLabel("Address:");
        lblPhone = new JLabel("Phone:");
        lblEmail = new JLabel("Email:");
        lblInchargeName = new JLabel("Incharge Name:");
        lblTimings = new JLabel("Timings:");
        
        // Initialize Text Fields
        txtCenterID = new JTextField(20);
        txtCenterName = new JTextField(20);
        txtAddress = new JTextField(20);
        txtPhone = new JTextField(20);
        txtEmail = new JTextField(20);
        txtInchargeName = new JTextField(20);
        txtTimings = new JTextField(20);
        
        // Initialize Buttons
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        
        btnReset = new JButton("Reset");
        btnReset.addActionListener(this);
        
        // Add components to the frame
        add(lblCenterID); add(txtCenterID);
        add(lblCenterName); add(txtCenterName);
        add(lblAddress); add(txtAddress);
        add(lblPhone); add(txtPhone);
        add(lblEmail); add(txtEmail);
        add(lblInchargeName); add(txtInchargeName);
        add(lblTimings); add(txtTimings);
        add(btnSubmit); add(btnReset);
    }
    
    // Method to establish a connection to the database
    public Connection getConnection() {
        Connection conn = null;
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish a connection
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database_name", "your_username", "your_password");
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnSubmit) {
            // Retrieve data from the form fields
            String centerID = txtCenterID.getText();
            String centerName = txtCenterName.getText();
            String address = txtAddress.getText();
            String phone = txtPhone.getText();
            String email = txtEmail.getText();
            String inchargeName = txtInchargeName.getText();
            String timings = txtTimings.getText();
            
            // Insert data into the database
            Connection conn = getConnection();
            if(conn != null) {
                try {
                    String query = "INSERT INTO vaccination_center_table (center_id, center_name, address, phone, email, incharge_name, timings) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement pstmt = conn.prepareStatement(query);
                    pstmt.setString(1, centerID);
                    pstmt.setString(2, centerName);
                    pstmt.setString(3, address);
                    pstmt.setString(4, phone);
                    pstmt.setString(5, email);
                    pstmt.setString(6, inchargeName);
                    pstmt.setString(7, timings);
                    
                    int rowsInserted = pstmt.executeUpdate();
                    if(rowsInserted > 0) {
                        // Display a confirmation message
                        JOptionPane.showMessageDialog(this, "Data saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                } finally {
                    try {
                        conn.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        } else if(e.getSource() == btnReset) {
            // Clear all the text fields
            txtCenterID.setText("");
            txtCenterName.setText("");
            txtAddress.setText("");
            txtPhone.setText("");
            txtEmail.setText("");
            txtInchargeName.setText("");
            txtTimings.setText("");
        }
    }
    
    public static void main(String[] args) {
        VaccinationCenterForm form = new VaccinationCenterForm();
        form.setVisible(true);
    }
}