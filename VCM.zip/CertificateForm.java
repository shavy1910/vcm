/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CertificateForm extends JFrame implements ActionListener {

    // Labels
    JLabel lblCertificateID, lblDosageID, lblIssueDate, lblCertiNo, lblStatus;
    
    // Text fields
    JTextField txtCertificateID, txtDosageID, txtIssueDate, txtCertiNo, txtStatus;
    
    // Buttons
    JButton btnSubmit, btnReset;
    
    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/your_database"; // Update with your database URL
    private static final String DB_USER = "your_username"; // Update with your database username
    private static final String DB_PASSWORD = "your_password"; // Update with your database password
    
    public CertificateForm() {
        // Frame settings
        setTitle("Certificate Form");
        setSize(400, 300);
        setLayout(new GridLayout(6, 2));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Initialize Labels
        lblCertificateID = new JLabel("Certificate ID:");
        lblDosageID = new JLabel("Dosage ID:");
        lblIssueDate = new JLabel("Issue Date:");
        lblCertiNo = new JLabel("Certificate Number:");
        lblStatus = new JLabel("Status:");
        
        // Initialize Text Fields
        txtCertificateID = new JTextField(20);
        txtDosageID = new JTextField(20);
        txtIssueDate = new JTextField(20);
        txtCertiNo = new JTextField(20);
        txtStatus = new JTextField(20);
        
        // Initialize Buttons
        btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener(this);
        
        btnReset = new JButton("Reset");
        btnReset.addActionListener(this);
        
        // Add components to the frame
        add(lblCertificateID); add(txtCertificateID);
        add(lblDosageID); add(txtDosageID);
        add(lblIssueDate); add(txtIssueDate);
        add(lblCertiNo); add(txtCertiNo);
        add(lblStatus); add(txtStatus);
        add(btnSubmit); add(btnReset);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnSubmit) {
            // Retrieve data from the form fields
            String certificateID = txtCertificateID.getText();
            String dosageID = txtDosageID.getText();
            String issueDate = txtIssueDate.getText();
            String certiNo = txtCertiNo.getText();
            String status = txtStatus.getText();
            
            // Database connection
            Connection conn = null;
            PreparedStatement pstmt = null;
            
            try {
                // Connect to the database
                conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                
                // SQL Insert query
                String sql = "INSERT INTO certificates (certificate_id, dosage_id, issue_date, certi_no, status) VALUES (?, ?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, certificateID);
                pstmt.setString(2, dosageID);
                pstmt.setString(3, issueDate);
                pstmt.setString(4, certiNo);
                pstmt.setString(5, status);
                
                // Execute the query
                pstmt.executeUpdate();
                
                // Display a confirmation message
                JOptionPane.showMessageDialog(this, "Data saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                // Close database resources
                try {
                    if (pstmt != null) pstmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            
        } else if(e.getSource() == btnReset) {
            // Clear all the text fields
            txtCertificateID.setText("");
            txtDosageID.setText("");
            txtIssueDate.setText("");
            txtCertiNo.setText("");
            txtStatus.setText("");
        }
    }
    
    public static void main(String[] args) {
          
        CertificateForm form = new CertificateForm();
        form.setVisible(true);
    }
}